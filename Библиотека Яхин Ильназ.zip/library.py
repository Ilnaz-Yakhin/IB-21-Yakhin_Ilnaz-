from re import A

class Book:
    ## Инициализация
    def __init__(self, name, author, time, izdat, opisanie, tir, gud):
        self.name = name.strip()
        self.author = author.strip()
        self.time = time.strip()
        self.izdat = izdat.strip()
        self.opisanie = opisanie.strip()
        self.tir = tir.strip()
        self.gud = gud.strip()
    
    ## Вывод содержимого экземпляра (вывод книги)
    def print(self):
        
        print(f"Название книги : {self.name}\n"
              f"Автор: {self.author}\n"
              f"Год Печати : {self.time}\n"
              f"Издатель: {self.izdat}\n"
              f"Описание: {self.opisanie}\n"
              f"Тираж №: {self.tir}\n"
              f"Тип Обложки: {self.gud}\n")

    ## Возвращает название книги
    def get_name(self):
        return self.name

    ## Меняет название
    def set_name(self, name):
        self.name = name

    ## Возвращает автора
    def get_author(self):
        return self.author

    ## Меняет автора
    def set_author(self, author):
        self.author = author

    ## Возвращает год, в котором книга была написана
    def get_time(self):
        return self.time

    ## Меняет год
    def set_time(self, time):
        self.time = time

    ## Возвращает издателя
    def get_izdat(self):
        return self.izdat

    ## Меняет издателя
    def set_izdat(self, izdat):
        self.izdat = izdat

    ## Возвращает описание
    def get_opisanie(self):
        return self.opisanie

    ## Меняет описание
    def set_opisanie(self, opisanie):
        self.opisanie = opisanie
    
    def get_tir(self):
    	return self.tir

    def set_tir(self, tir):
    	self.tir = tir

    def get_gud(self):
    	return self.gud

    def set_gud(self, gud):
    	self.gud = gud
        
def get_field(help_str, old_val):
        a = input(help_str).strip()
        if a != '':
            
            return a
        return old_val

def save(libra):
  f = open('library.txt', 'w', encoding="utf-8")
  for i in libra:
    f.write(str(i.name)+'.'+str(i.author)+'.'+str(i.time)+'.'+str(i.izdat)+'.'+str(i.opisanie)+'.'+str(i.tir)+'.'+str(i.gud)+"\n")

## Создаем 1 книгу
Library = []
fLibrary = open('library.txt', encoding="utf-8")  #library-библиотека(список книг)
for line in fLibrary:
  Library.append(Book(line.split(".")[0], line.split(".")[1], line.split(".")[2], line.split(".")[3], line.split(".")[4], line.split(".")[5], line.split(".")[6]))
## "Рабочий" цикл. Здесь выбираем действия, которые нужно будет произвести
while True:
    print(f"Введите команды, чтобы:\n"
          f"info - Список Общих книг\n"
          f"up - Добавить книну в БД\n"
          f"ch- Изменить книгу\n"
          f"find - Поиск книги\n"
          f"dl - Удалить книгу\n"
          f"ex - выход из задачи")
    n = input()
    if n == "info":
        print(f"СПИСОК КНИГ:")
        ## Вывод списка книг
        for i in range(len(Library)):
            print(f"КНИГА №{i+1}")
            Library[i].print()
    elif n == "up":
        print(f"Введите даные новой книги:")
        name = input("название книги: ")
        author = input("Автор: ")
        time = input("Год Печати: ")
        izdat = input("Издатель: ")
        opisanie = input("Описание: ")
        tir = input("Тираж")
        gud = input("Тип Обложки")
        ## Добавление новой книги в список книг
        Library.append(Book(name, author, time, izdat, opisanie, tir, gud))
        save(Library)
    elif n == "ch":
        print(f"Введите данные измененной книги:\n")
        book_num = int(input("Изменение книги №"))
        if book_num > len(Library):
          print("Неверная цифра")
          continue
        name = get_field("Название Книги( )"+Library[book_num-1].name+'): ', Library[book_num-1].get_name())
        author = get_field("Автор(  )"+Library[book_num-1].author+'): ', Library[book_num-1].get_author())
        time = get_field("Год Публикации( )"+Library[book_num-1].time+'): ', Library[book_num-1].get_time())
        izdat = get_field("Издатель( )"+Library[book_num-1].izdat+'): ', Library[book_num-1].get_izdat())
        opisanie = get_field("Описание( )"+Library[book_num-1].opisanie+'): ', Library[book_num-1].get_opisanie())
        tir = get_field("Тираж( ) "+Library[book_num-1].tir+'): ', Library[book_num-1].get_tir())
        gud = get_field("Тип Обложки( ) "+Library[book_num-1].gud+'): ', Library[book_num-1].get_gud())
        Library[book_num-1] = Book(name, author, time, izdat, opisanie, tir, gud)
        save(Library)
    elif n == "dl":
        ## Удаляем книгу
        book_num = int(input("Удаление книги №"))
        if book_num > len(Library):
          print("Неверная цифра")
          continue

        del Library[book_num-1] 
        save(Library)
    elif n == "find":
        poisk = input("Введите название книги: ")
        result = filter(lambda book: poisk.lower() in book.name.lower(),Library)
        for i, book in enumerate(result, 1):
            print(f"КНИГА №{i}")
            book.print()
    elif n == "ex":
        ## Завершение работы
        break
    else:
        print("Возможна ошибка или Неправильный запрос данных, Попробуйте потом!")
print("Вы вышли из БД!\n До свидания!")